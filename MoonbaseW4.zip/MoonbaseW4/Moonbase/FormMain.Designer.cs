﻿namespace Moonbase
{
    partial class Moonbase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Moonbase));
            this.GBcenconroom = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BTNsec = new System.Windows.Forms.Button();
            this.BTNeng = new System.Windows.Forms.Button();
            this.BTNcoms = new System.Windows.Forms.Button();
            this.BTNops = new System.Windows.Forms.Button();
            this.GBpernav = new System.Windows.Forms.GroupBox();
            this.BTNcencon = new System.Windows.Forms.Button();
            this.GBcenconroom.SuspendLayout();
            this.GBpernav.SuspendLayout();
            this.SuspendLayout();
            // 
            // GBcenconroom
            // 
            this.GBcenconroom.BackColor = System.Drawing.Color.Gainsboro;
            this.GBcenconroom.Controls.Add(this.textBox2);
            this.GBcenconroom.Controls.Add(this.label2);
            this.GBcenconroom.Controls.Add(this.textBox1);
            this.GBcenconroom.Controls.Add(this.label1);
            this.GBcenconroom.Location = new System.Drawing.Point(42, 23);
            this.GBcenconroom.Name = "GBcenconroom";
            this.GBcenconroom.Size = new System.Drawing.Size(483, 471);
            this.GBcenconroom.TabIndex = 0;
            this.GBcenconroom.TabStop = false;
            this.GBcenconroom.Text = "Location Information";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(42, 148);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(404, 270);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = resources.GetString("textBox2.Text");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(38, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 26);
            this.label2.TabIndex = 2;
            this.label2.Text = "Room Description";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(42, 63);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(270, 35);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "Central Control Room";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(38, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Room Name";
            // 
            // BTNsec
            // 
            this.BTNsec.Location = new System.Drawing.Point(384, 173);
            this.BTNsec.Name = "BTNsec";
            this.BTNsec.Size = new System.Drawing.Size(141, 95);
            this.BTNsec.TabIndex = 3;
            this.BTNsec.Text = "Security";
            this.BTNsec.UseVisualStyleBackColor = true;
            this.BTNsec.Click += new System.EventHandler(this.BTNres_Click);
            // 
            // BTNeng
            // 
            this.BTNeng.Location = new System.Drawing.Point(212, 39);
            this.BTNeng.Name = "BTNeng";
            this.BTNeng.Size = new System.Drawing.Size(141, 95);
            this.BTNeng.TabIndex = 2;
            this.BTNeng.Text = "Engineering";
            this.BTNeng.UseVisualStyleBackColor = true;
            this.BTNeng.Click += new System.EventHandler(this.BTNeng_Click);
            // 
            // BTNcoms
            // 
            this.BTNcoms.Location = new System.Drawing.Point(212, 303);
            this.BTNcoms.Name = "BTNcoms";
            this.BTNcoms.Size = new System.Drawing.Size(141, 95);
            this.BTNcoms.TabIndex = 4;
            this.BTNcoms.Text = "Communications";
            this.BTNcoms.UseVisualStyleBackColor = true;
            this.BTNcoms.Click += new System.EventHandler(this.BTNcoms_Click);
            // 
            // BTNops
            // 
            this.BTNops.Location = new System.Drawing.Point(42, 173);
            this.BTNops.Name = "BTNops";
            this.BTNops.Size = new System.Drawing.Size(141, 95);
            this.BTNops.TabIndex = 1;
            this.BTNops.Text = "Operations";
            this.BTNops.UseVisualStyleBackColor = true;
            this.BTNops.Click += new System.EventHandler(this.BTNops_Click);
            // 
            // GBpernav
            // 
            this.GBpernav.BackColor = System.Drawing.SystemColors.Window;
            this.GBpernav.Controls.Add(this.BTNcencon);
            this.GBpernav.Controls.Add(this.BTNops);
            this.GBpernav.Controls.Add(this.BTNcoms);
            this.GBpernav.Controls.Add(this.BTNeng);
            this.GBpernav.Controls.Add(this.BTNsec);
            this.GBpernav.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GBpernav.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.GBpernav.Location = new System.Drawing.Point(1278, 25);
            this.GBpernav.Name = "GBpernav";
            this.GBpernav.Size = new System.Drawing.Size(556, 455);
            this.GBpernav.TabIndex = 5;
            this.GBpernav.TabStop = false;
            this.GBpernav.Text = "Personal Nav Device";
            // 
            // BTNcencon
            // 
            this.BTNcencon.Enabled = false;
            this.BTNcencon.Location = new System.Drawing.Point(212, 161);
            this.BTNcencon.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BTNcencon.Name = "BTNcencon";
            this.BTNcencon.Size = new System.Drawing.Size(135, 118);
            this.BTNcencon.TabIndex = 0;
            this.BTNcencon.Text = "Central Control";
            this.BTNcencon.UseVisualStyleBackColor = true;
            this.BTNcencon.Click += new System.EventHandler(this.BTNcencon_Click);
            // 
            // Moonbase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1898, 1024);
            this.Controls.Add(this.GBpernav);
            this.Controls.Add(this.GBcenconroom);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Moonbase";
            this.Text = "Cosmos Command";
            this.GBcenconroom.ResumeLayout(false);
            this.GBcenconroom.PerformLayout();
            this.GBpernav.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GBcenconroom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button BTNsec;
        private System.Windows.Forms.Button BTNeng;
        private System.Windows.Forms.Button BTNcoms;
        private System.Windows.Forms.Button BTNops;
        private System.Windows.Forms.GroupBox GBpernav;
        private System.Windows.Forms.Button BTNcencon;
    }
}

