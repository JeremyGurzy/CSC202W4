﻿/*
 Jeremy Gurzynski
 CSC202
 jgurzynski85952@uat.edu
 Week 3 MoonBase Alpha II Assignment
 */

//These lines are used for various functionalities of C#
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

//Name of our file
namespace Moonbase
{
    //Declares our Moonbase that inherits from form
    public partial class Moonbase : Form
    {
        //private int created for tracking locations, kept this so I did not have to edit previous one any further
        private int currentLoc;  

        //Global variables for the whole form, each have 5
        public string[] RN = new string[5];
        public string[] Desc = new string[5];
        public string[] BI = new string[5];

        //created a class called area for room names, descriptions and background images
        class area 
        {
            //These lines are changed the public strings to private
            private string[] roomNames = new string[5];
            private string[] roomDesc = new string[5];
            private string[] backgroundImage = new string[5];

            //constructor for our arrays
            public area(string[] RN, string[] Desc, string[] BI)
            {
                //for loop 
                //i< is how many times you want something to be done, it will be less than 5. i++ goes up by one
                for (int i = 0; i<roomNames.Length; i++) 
                {
                    //these copy the arrays, EXPLAINED: roomname "0" will be the same as RN "0"
                    roomNames[i] = RN[i];
                    roomDesc[i] = Desc[i];
                    backgroundImage[i] = BI[i];
                }
            }
            //string function will get the room name and then set it
            public string getRoom(int i)
            {
                //function will return the room name and the integer assigned from the array
                return roomNames[i];
            }
            //string function will get the description and then set it
            public string getDesc(int i) 
            {
                //function will return the room description and the integer assigned from the array
                return roomDesc[i];
            }
            //string function for the background image and then set it
            public string getBackImage(int i)
            {
                //function will return the background image and the integer assigned from the array
                return backgroundImage[i]; 
            }
        }

        //Constructor for our form
        public Moonbase()
        {
            //Initializes control objects, properties, and adds to proper control collections.
            InitializeComponent();


            //These lines are the room names for each area
            RN[0] = "Central Control Room";
            RN[1] = "Operations Room";
            RN[2] = "Security Room";
            RN[3] = "Communications Room";
            RN[4] = "Engineering Room";

            //Description for Central Control Room
            Desc[0] = "A vast and open circular room that is the center of the Cosmos Command. The Central Control Room is the brains of the base and connects with four work stations: operations, engineering, security, and communcations station. \r\n\r\nThe Central Control Room breaks off into several corridors that connect around the base creating easier access to all compartments in the event of an emergency.";
            //Description for Operations
            Desc[1] = " Oversees and coordinates all mission activities and operational directives. Here is where mission plans are coordinated, schedules are managed, and vital decisions are made. It houses advanced monitoring screens displaying real-time data from various base systems, ensuring everything from life support to scientific experiments runs smoothly.";
            //DESCRIPTION FOR SECURITY
            Desc[2] = "Conducts and oversees all security of the command. Security Personnel monitor all interior and exterior cameras ensuring the safety of all personnel within the command. This room is equipped with state-of-the-art surveillance systems, security gear, security weaponry, and more.\r\n";
            //Description for Communications
            Desc[3] = "Manages all external communications between Earth and the Moon, as well as internal communications within the base. The Communications Room is equipped with advanced communication systems, ensuring that messages, video calls, and critical data flow smoothly from here to Earth.";
            //Description for Engineering
            Desc[4] = "Monitors all technical systems and base infrastructure. Engineers and technicians maintain and improve the base's infrastructure and technology. Here you will find various equipment such as advanced tools, 3D printers for rapid prototyping, and diagnostic stations to ensure every component of the base operates at peak performance.";

            //These lines are all set with the path for each background image
            BI[0] = "ControlRoom.jpg";
            BI[1] = "opsroom.jpg";
            BI[2] = "secroom.jpg";
            BI[3] = "comroom.jpg";
            BI[4] = "engRoom.jpg";
        }

        //Log File Function with the location string variable
        private void logLocation(string location) 
        {
            //This is for collecting the current date and time with the location
            string logMessage = $"{DateTime.Now}: Moved to {location}";
            //This is where the information will be logged
            string logFile = "locationLog.txt"; 
            //StreamWriter is used for writing to the log files
            using (StreamWriter lw = File.AppendText(logFile)) 
            {
                //Function for writing the lines
                lw.WriteLine(logMessage);
            }
        }

        //Function for each area
        //function for central control room, 0
        private void centralControlRoom() 
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(0);
            string desc = Cosmos.getDesc(0);

            //Message box will display with the location with assigned number in array function, $ symbol for calling the string
            MessageBox.Show($"Going back to: {Cosmos.getRoom(0)}");
            //Call the location with the assigned number from our array
            currentLoc = 0;


            //if created to show and hide necessary data
            if (currentLoc == 0)
            {
                ///These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = false;
                BTNeng.Enabled = true;
                BTNcoms.Enabled = true;
                BTNops.Enabled = true;
                BTNsec.Enabled = true;

                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 23);

                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(0));
            }
            //Call log location function with the name of the room for logging
            logLocation("Central Control Room");

        }
        //Function for Operations, 1
        private void operationsRoom() 
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(1);
            string desc = Cosmos.getDesc(1);

            //Message box will display location name and short description from the array data
            MessageBox.Show($"Going to: {Cosmos.getRoom(1)}");

            //sets the current location
            currentLoc = 1;

        
            //if created to show and hide necessary data
            if (currentLoc == 1)
            {
                //These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = true;
                BTNeng.Enabled = false;
                BTNcoms.Enabled = false;
                BTNops.Enabled = false;
                BTNsec.Enabled = false;

                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 23);

                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(1));

            }
            //Call log location function with the name of the room for logging
            logLocation("Operations Room");
        }
        //Function for Security, 2
        private void securityRoom() 
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(2);
            string desc = Cosmos.getDesc(2);
            

            //Message box will display location name and short description from the array data
            MessageBox.Show($"Going back to: {Cosmos.getRoom(2)}");
            //sets the current location
            currentLoc = 2;

            //if created to show and hide necessary data
            if (currentLoc == 2)
            {
                //These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = true;
                BTNeng.Enabled = false;
                BTNcoms.Enabled = false;
                BTNops.Enabled = false;
                BTNsec.Enabled = false;


                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 23);

                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(2));


            }
            //Call log location function with the name of the room for logging
            logLocation("Security Room");
        }
        //Function for Communications
        private void communicationsRoom()
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(3);
            string desc = Cosmos.getDesc(3);


            //Message box will display location name and short description from the array data
            MessageBox.Show($"Going to: {Cosmos.getRoom(3)}");
            //Sets the current location
            currentLoc = 3;

            //if created to show and hide necessary data
            if (currentLoc == 3)
            {
                //These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = true;
                BTNeng.Enabled = false;
                BTNcoms.Enabled = false;
                BTNops.Enabled = false;
                BTNsec.Enabled = false;


                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 23);

                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(3));
            }
        
            //Call log location function with the name of the room for logging
            logLocation("Communications Room");
        }
        //Function for Engineering
        private void engineeringRoom()
        {
            //Call the class and call it Cosmos with arrays sent into it
            area Cosmos = new area(RN, Desc, BI);
            //These two lines will call the functions with the assigned array data to change the room name and description in our groupboxes
            string room = Cosmos.getRoom(4);
            string desc = Cosmos.getDesc(4);


            //Message box will display location name and short description from the array data
            MessageBox.Show($"Going to: {Cosmos.getRoom(4)}");

            //set the current location for the if statement
            currentLoc = 4;

            //if created to show and hide necessary data
            if (currentLoc == 4)
            {
                //These lines are disabling and enabling certain buttons
                BTNcencon.Enabled = true;
                BTNeng.Enabled = false;
                BTNcoms.Enabled = false;
                BTNops.Enabled = false;
                BTNsec.Enabled = false;

                //sets the location of a group box
                GBcenconroom.Location = new Point(42, 340);

                //next two lines set the text box information to the array assigned
                textBox1.Text = room;
                textBox2.Text = desc;
                //sets the background image according to the array assigned
                BackgroundImage = Image.FromFile(Cosmos.getBackImage(4));





            }
            //Stored the hide and shows in an if statement

            //Call log location function with the name of the room for logging
            logLocation("Engineering Room");
        }
        //And finally the buttons that activate each function
        //Function called when button is pressed.
        private void BTNops_Click(object sender, EventArgs e)
        {

            //Calling function for the area
            operationsRoom();
            
        }
        //Function called when button is pressed.
        private void BTNeng_Click(object sender, EventArgs e)
        {

            //Calling function for the area
            engineeringRoom();
            
        }
        //Function called when button is pressed.
        private void BTNres_Click(object sender, EventArgs e)
        {

            //Calling function for the area
            securityRoom();
        }
        //Function called when button is pressed.
        private void BTNcoms_Click(object sender, EventArgs e)
        {
   
            //call function for this area
            communicationsRoom();
        }
        //Function called when button is clicked
        private void BTNcencon_Click(object sender, EventArgs e)
        {

            //Calling function for the area
            centralControlRoom();
        }

    }
}
